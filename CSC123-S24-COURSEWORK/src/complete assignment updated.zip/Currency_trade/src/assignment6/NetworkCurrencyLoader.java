package assignment6;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;

public class NetworkCurrencyLoader extends AbstractCurencyLoader {

	@Override
	protected InputStream getStream() {
		try {
            URL url = new URL("http://www.usman.cloud/banking/exchange-rate.csv");
            URLConnection urlCon = url.openConnection();
            return urlCon.getInputStream();
        } catch (IOException e) {
            e.printStackTrace();
            return null; 
        }
	}

}
