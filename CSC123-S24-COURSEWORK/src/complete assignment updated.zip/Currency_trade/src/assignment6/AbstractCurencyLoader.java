package assignment6;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

public abstract class AbstractCurencyLoader {

	public static AbstractCurencyLoader getInstance(String type) {
		type = type.toUpperCase().strip();

		if (type.equals("FILE")) {
			return new FileCurrencyLoader();
		} else if (type.equals("STRING")) {
			return new StringHook();
		} else if (type.equals("NETWORK")) {
			return new NetworkCurrencyLoader();

		}

		return null;

	}

	public Map<String, MyCurrency> loadCurrencies() throws Exception {
		Map<String, MyCurrency> mcurrencyMap = new HashMap<String, MyCurrency>();
		
		BufferedReader br = new BufferedReader(new InputStreamReader(getStream()));

		String line = null;
		while ((line = br.readLine()) != null) {
			String[] tokens = line.strip().split(",");
			String currencyCode = tokens[0].strip();
			double exchangeRate = Double.valueOf(tokens[2]);
			mcurrencyMap.put(currencyCode, new MyCurrency(currencyCode, exchangeRate));
		}
		
		
		return mcurrencyMap;
	}

	protected abstract InputStream getStream();

}
