package assignment6;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

public class FileCurrencyLoader extends AbstractCurencyLoader {

	@Override
	protected InputStream getStream() {
		try {
			return new FileInputStream("currencies.csv");
		} catch (FileNotFoundException e) {
			System.out.println("The file currencies.csv not found");
			return null; 
		}
	}
}
