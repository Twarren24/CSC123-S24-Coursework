package org.libary;


import java.text.SimpleDateFormat;
import java.util.Date;


public class DVD extends Material {
    private Date releaseDate;  // The release date of the DVD
    private int duration;      // The duration of the DVD in minutes

    /**
     * Constructor for initializing a DVD object.
     * @param title The title of the DVD.
     * @param uniqueReference The unique reference identifier for the DVD.
     * @param suitableForChildren Indicates whether the DVD is suitable for children.
     * @param replacementValue The replacement cost of the DVD.
     * @param location The physical location of the DVD within the library.
     * @param releaseDate The release date of the DVD.
     * @param duration The duration of the DVD in minutes.
     */
    public DVD(String title, String uniqueReference, boolean suitableForChildren, double replacementValue, String location, Date releaseDate, int duration) {
        super(title, uniqueReference, suitableForChildren, replacementValue, location);
        this.releaseDate = releaseDate;
        this.duration = duration;
    }

    // Getters and setters for DVD-specific fields
    public Date getReleaseDate() {
        return releaseDate;
    }

    public void setReleaseDate(Date releaseDate) {
        this.releaseDate = releaseDate;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    /**
     * Checks if the DVD is currently available for loan.
     * @return true if the DVD is not currently loaned out, false otherwise.
     */

    @Override
    public boolean isAvailable() {
        return available;
    }

    /**
     * Provides a string representation of the DVD's details.
     * @return A string detailing the DVD's attributes including release date and duration.
     */
    // DVD
    @Override
    public String toString() {
        SimpleDateFormat df = new SimpleDateFormat("MM/dd/yyyy");
        return String.join(",",
                "DVD",
                getTitle(),
                getUniqueReference(),
                String.valueOf(isSuitableForChildren()),
                String.format("%.2f", getReplacementValue()),
                getLocation(),
                df.format(getReleaseDate()),
                String.valueOf(getDuration())
        );
    }
}
