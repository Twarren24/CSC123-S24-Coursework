package org.libary;


import java.text.SimpleDateFormat;
import java.util.Date;

import java.util.Date;

public class Loan {
    private String itemReference;   // Reference identifier for the loaned item
    private String title;           // Title of the loaned item
    private String membershipNumber;// Membership number of the borrower
    private String borrowerName;    // Full name of the borrower
    private Date dueDate;           // Date when the item is due back

    /**
     * Constructor to initialize a Loan object.
     * @param itemReference The reference identifier of the loaned item.
     * @param title The title of the loaned item.
     * @param membershipNumber The membership number of the borrower.
     * @param borrowerName The full name of the borrower.
     * @param dueDate The date when the loaned item is due to be returned.
     */
    public Loan(String itemReference, String title, String membershipNumber, String borrowerName, Date dueDate) {
        this.itemReference = itemReference;
        this.title = title;
        this.membershipNumber = membershipNumber;
        this.borrowerName = borrowerName;
        this.dueDate = dueDate;
    }

    // Getters and setters for all fields
    public String getItemReference() {
        return itemReference;
    }

    public void setItemReference(String itemReference) {
        this.itemReference = itemReference;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getMembershipNumber() {
        return membershipNumber;
    }

    public void setMembershipNumber(String membershipNumber) {
        this.membershipNumber = membershipNumber;
    }

    public String getBorrowerName() {
        return borrowerName;
    }

    public void setBorrowerName(String borrowerName) {
        this.borrowerName = borrowerName;
    }

    public Date getDueDate() {
        return dueDate;
    }

    public void setDueDate(Date dueDate) {
        this.dueDate = dueDate;
    }

    /**
     * Provides a string representation of the loan's details.
     * @return A string detailing the specifics of the loan including item title, borrower's name, and due date.
     */
    @Override
    public String toString() {
        SimpleDateFormat df = new SimpleDateFormat("MM/dd/yyyy");
        return String.join(",",
                getItemReference(),
                getTitle(),
                getMembershipNumber(),
                getBorrowerName(),
                df.format(getDueDate())
        );
    }

}

