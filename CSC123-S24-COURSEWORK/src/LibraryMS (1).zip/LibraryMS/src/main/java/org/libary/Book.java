package org.libary;


public class Book extends Material {
    private String author;          // The author of the book
    private String isbn;            // The International Standard Book Number for the book
    private int numberOfPages;      // The total number of pages in the book

    /**
     * Constructor for initializing a Book object.
     * @param title The title of the book.
     * @param uniqueReference The unique reference identifier for the book.
     * @param suitableForChildren Indicates whether the book is suitable for children.
     * @param replacementValue The replacement cost of the book.
     * @param location The physical location of the book within the library.
     * @param author The author of the book.
     * @param isbn The International Standard Book Number of the book.
     * @param numberOfPages The number of pages in the book.
     */
    public Book(String title, String uniqueReference, boolean suitableForChildren, double replacementValue, String location, String author, String isbn, int numberOfPages) {
        super(title, uniqueReference, suitableForChildren, replacementValue, location);
        this.author = author;
        this.isbn = isbn;
        this.numberOfPages = numberOfPages;
    }

    // Getters and setters for additional book fields
    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public int getNumberOfPages() {
        return numberOfPages;
    }

    public void setNumberOfPages(int numberOfPages) {
        this.numberOfPages = numberOfPages;
    }

    /**
     * Checks if the book is currently available for loan.
     * @return true if the book is not currently loaned out, false otherwise.
     */
    @Override
    public boolean isAvailable() {
        return available;
    }

    /**
     * Provides a string representation of the book's details.
     * @return A string detailing the book's attributes including author and ISBN.
     */
    @Override
    public String toString() {
        return String.join(",",
                "Book",
                getTitle(),
                getUniqueReference(),
                String.valueOf(isSuitableForChildren()),
                String.format("%.2f", getReplacementValue()),
                getLocation(),
                getAuthor(),
                getIsbn(),
                String.valueOf(getNumberOfPages())
        );
    }

}
