package org.libary;

import com.google.gson.annotations.Expose;

import java.text.SimpleDateFormat;
import java.util.Date;

public class AdultMember extends Member {



    @Override
    public String toString() {
        SimpleDateFormat df = new SimpleDateFormat("MM/dd/yyyy");
        return "Adult," + super.toString();
    }

    /**
     * Constructor to initialize an AdultMember object using the constructor of the superclass Member.
     * @param firstName The first name of the adult member.
     * @param lastName The last name of the adult member.
     * @param dateOfBirth The date of birth of the adult member.
     * @param city The city where the adult member resides.
     * @param zipCode The postal code of the adult member's city.
     * @param membershipNumber The unique membership number assigned to the adult member.
     */
    public AdultMember(String firstName, String lastName, Date dateOfBirth, String city, String zipCode, String membershipNumber) {
        super(firstName, lastName, dateOfBirth, city, zipCode, membershipNumber);
    }

    /**
     * Determines if the member is a child. Overrides the isChild method from the Member class.
     * @return false, since this class represents an adult member.
     */
    @Override
    public boolean isChild() {
        return false;
    }
}

