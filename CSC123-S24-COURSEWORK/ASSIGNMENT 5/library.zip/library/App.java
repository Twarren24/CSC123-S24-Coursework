

import java.io.IOException;
import java.text.ParseException;
import java.util.Calendar;
import java.util.Scanner;
import java.text.SimpleDateFormat;
import java.util.Date;

public class App {
    private static Library library = new Library(); // Assuming the Library constructor initializes lists.
    private static Scanner scanner = new Scanner(System.in);
    public static void main(String[] args) throws IOException {
        library.loadLibraryState();
        runApplication();
        library.saveLibraryState();
    }

    private static void runApplication() {
         System.out.println("Hello and welcome to the Library Management System!");

        while (true) {
            System.out.println("\n--- Library Menu ---");
            System.out.println("1 - New Membership");
            System.out.println("2 - Add Material");
            System.out.println("3 - Issue Item");
            System.out.println("4 - Return Item");
            System.out.println("5 - Report Inventory");
            System.out.println("6 - Report Loans");
            System.out.println("7 - Lookup Membership");
            System.out.println("8 - Exit");
            System.out.print("Please enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // consume newline left-over

            switch (choice) {
                case 1:
                    addNewMember();
                    break;
                case 2:
                    addNewMaterial();
                    break;
                case 3:
                    issueItem();
                    break;
                case 4:
                    returnItem();
                    break;
                case 5:
                    reportInventory();
                    break;
                case 6:
                    reportLoans();
                    break;
                case 7:
                    lookupMembership();
                    break;
                case 8:
                    System.out.println("Exiting... Thank you for using the Library Management System.");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }


    private static void addNewMember() {
        System.out.print("Enter first name: ");
        String firstName = scanner.nextLine();
        System.out.print("Enter last name: ");
        String lastName = scanner.nextLine();

        Date dob = null;
        while (dob == null) {
            System.out.print("Enter date of birth (MM/dd/yyyy): ");
            String dobStr = scanner.nextLine();
            dob = parseDate(dobStr);
            if (dob == null) {
                System.out.println("Invalid date format. Please use MM/dd/yyyy.");
            }
        }

        System.out.print("Enter city: ");
        String city = scanner.nextLine();
        System.out.print("Enter zip code: ");
        String zipCode = scanner.nextLine();

        Member member;
        if (calculateAge(dob) < 18) {
            System.out.println("Member is a child. Enter guardian details.");
            AdultMember guardian = addGuardianDetails(city, zipCode);
            if (guardian == null) {
                return; // Stop the process if guardian details are invalid
            }
            String childMembershipNumber = generateMembershipNumber();
            member = new ChildMember(firstName, lastName, dob, city, zipCode, childMembershipNumber, guardian);
        } else {
            String membershipNumber = generateMembershipNumber();
            member = new AdultMember(firstName, lastName, dob, city, zipCode, membershipNumber);
        }

        library.addMember(member);
        System.out.println("New member added successfully: \n---------\n" + member+"\n---------");
    }

    private static AdultMember addGuardianDetails(String city, String zipCode) {
        System.out.print("Enter guardian's first name: ");
        String guardianFirstName = scanner.nextLine();
        System.out.print("Enter guardian's last name: ");
        String guardianLastName = scanner.nextLine();

        Date guardianDob = null;
        while (guardianDob == null) {
            System.out.print("Enter guardian's date of birth (MM/dd/yyyy): ");
            String guardianDobStr = scanner.nextLine();
            guardianDob = parseDate(guardianDobStr);
            if (guardianDob == null) {
                System.out.println("Invalid date format for guardian. Please use MM/dd/yyyy.");
            }
        }

        if (calculateAge(guardianDob) < 18) {
            System.out.println("Guardian cannot be a child.");
            return null;
        }

        String guardianMembershipNumber = generateMembershipNumber();
        return new AdultMember(guardianFirstName, guardianLastName, guardianDob, city, zipCode, guardianMembershipNumber);
    }


    private static Date parseDate(String dateStr) {
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
        sdf.setLenient(false);
        try {
            return sdf.parse(dateStr);
        } catch (ParseException e) {
            return null;
        }
    }

    private static int calculateAge(Date dob) {
        Calendar dobCalendar = Calendar.getInstance();
        dobCalendar.setTime(dob);
        Calendar today = Calendar.getInstance();
        int age = today.get(Calendar.YEAR) - dobCalendar.get(Calendar.YEAR);
        if (today.get(Calendar.DAY_OF_YEAR) < dobCalendar.get(Calendar.DAY_OF_YEAR)) {
            age--;
        }
        return age;
    }

    private static String generateMembershipNumber() {
        return "MEM" + System.currentTimeMillis();
    }


    private static void addNewMaterial() {
        System.out.println("Select the type of material to add:");
        System.out.println("1 - Book");
        System.out.println("2 - Magazine");
        System.out.println("3 - DVD");
        System.out.print("Enter choice: ");
        int type = scanner.nextInt();
        scanner.nextLine();  // Consume newline left-over

        System.out.print("Enter title: ");
        String title = scanner.nextLine();
        System.out.print("Enter unique reference: ");
        String uniqueReference = scanner.nextLine();
        System.out.print("Is it suitable for children? (yes/no): ");
        boolean suitableForChildren = scanner.nextLine().trim().equalsIgnoreCase("yes");
        System.out.print("Enter replacement value: ");
        double replacementValue = scanner.nextDouble();
        scanner.nextLine();  // Consume newline left-over
        System.out.print("Enter location (e.g., shelf id.location): ");
        String location = scanner.nextLine();

        Material material;
        switch (type) {
            case 1:  // Book
                System.out.print("Enter author: ");
                String author = scanner.nextLine();
                System.out.print("Enter ISBN: ");
                String isbn = scanner.nextLine();
                System.out.print("Enter number of pages: ");
                int numberOfPages = scanner.nextInt();
                material = new Book(title, uniqueReference, suitableForChildren, replacementValue, location, author, isbn, numberOfPages);
                break;
            case 2:  // Magazine
                System.out.print("Enter publication date (MM/dd/yyyy): ");
                String pubDateStr = scanner.nextLine();
                Date publicationDate = parseDate(pubDateStr);
                if (publicationDate == null) {
                    System.out.println("Invalid date format.");
                    return;
                }
                System.out.print("Enter issue number: ");
                int issueNumber = scanner.nextInt();
                material = new Magazine(title, uniqueReference, suitableForChildren, replacementValue, location, publicationDate, issueNumber);
                break;
            case 3:  // DVD
                System.out.print("Enter release date (MM/dd/yyyy): ");
                String relDateStr = scanner.nextLine();
                Date releaseDate = parseDate(relDateStr);
                if (releaseDate == null) {
                    System.out.println("Invalid date format.");
                    return;
                }
                System.out.print("Enter duration in minutes: ");
                int duration = scanner.nextInt();
                material = new DVD(title, uniqueReference, suitableForChildren, replacementValue, location, releaseDate, duration);
                break;
            default:
                System.out.println("Invalid material type selected.");
                return;
        }

        library.addMaterial(material);
        System.out.println("New material added successfully:  \n---------\n" + material+"\n---------");
    }




    private static void issueItem() {
        System.out.print("Enter membership number: ");
        String membershipNumber = scanner.nextLine();
        System.out.print("Enter item reference number: ");
        String itemReference = scanner.nextLine();

        try {
            library.issueItem(membershipNumber, itemReference);
            System.out.println("Item issued successfully.");
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    private static void returnItem() {
        System.out.print("Enter the item reference number to return: ");
        String itemReference = scanner.nextLine();

        try {
            library.returnItem(itemReference);
            System.out.println("Item returned successfully.");
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
        }
    }


    private static void reportInventory() {
        // Implementation: Simply call the method and print results
        System.out.println(library.reportInventory());
    }

    private static void reportLoans() {
        // Implementation: Simply call the method and print results
        System.out.println(library.reportLoans());
    }

    private static void lookupMembership() {
        System.out.print("Enter the membership ID to look up: ");
        String membershipId = scanner.nextLine();

        try {
            String memberDetails = library.lookupMembership(membershipId);
            System.out.println("Member Details:");
            System.out.println(memberDetails);
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
        }
    }


}
