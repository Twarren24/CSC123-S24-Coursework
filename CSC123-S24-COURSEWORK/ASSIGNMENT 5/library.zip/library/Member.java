

import java.util.Date;

import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public abstract class Member {
    protected String firstName;
    protected String lastName;
    protected Date dateOfBirth;
    protected String city;
    protected String zipCode;
    protected String membershipNumber;

    /**
     * Constructor to initialize a Member object.
     * @param firstName The first name of the member.
     * @param lastName The last name of the member.
     * @param dateOfBirth The date of birth of the member.
     * @param city The city where the member resides.
     * @param zipCode The postal code of the member's city.
     * @param membershipNumber The unique membership number assigned to the member.
     */
    public Member(String firstName, String lastName, Date dateOfBirth, String city, String zipCode, String membershipNumber) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.dateOfBirth = dateOfBirth;
        this.city = city;
        this.zipCode = zipCode;
        this.membershipNumber = membershipNumber;
    }



    /**
     * Determines if the member is a child based on their date of birth.
     * @return true if the member is under 18 years old, false otherwise.
     */
    public abstract boolean isChild();
    /**
     * Returns a string representation of the member's details.
     * @return A string containing all relevant member information.
     */
    @Override
    public String toString() {
        SimpleDateFormat df = new SimpleDateFormat("MM/dd/yyyy");
        return String.join(",",
                getMembershipNumber(),
                getFirstName() + " " + getLastName(),
                df.format(getDateOfBirth()),
                getCity(),
                getZipCode());
    }


    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public Date getDateOfBirth() {
        return dateOfBirth;
    }

    public String getCity() {
        return city;
    }

    public String getZipCode() {
        return zipCode;
    }

    public String getMembershipNumber() {
        return membershipNumber;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setDateOfBirth(Date dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public void setMembershipNumber(String membershipNumber) {
        this.membershipNumber = membershipNumber;
    }

    public String getFullName() {
        return (firstName +" "+ lastName);
    }
}
