

public abstract class Material {
    protected String title;                // The title of the material
    protected String uniqueReference;      // A unique identifier for the material
    protected boolean suitableForChildren; // Indicates if the material is suitable for children
    protected double replacementValue;     // The cost of replacement if lost or damaged
    protected String location;             // The location of the material within the library
    protected boolean available; // Track availability directly within the Material class

    /**
     * Constructor for initializing a Material object.
     * @param title The title of the material.
     * @param uniqueReference The unique reference identifier for the material.
     * @param suitableForChildren Indicates whether the material is suitable for children.
     * @param replacementValue The replacement cost of the material.
     * @param location The physical location of the material within the library.
     */
    public Material(String title, String uniqueReference, boolean suitableForChildren, double replacementValue, String location) {
        this.title = title;
        this.uniqueReference = uniqueReference;
        this.suitableForChildren = suitableForChildren;
        this.replacementValue = replacementValue;
        this.location = location;
        this.available = true; // Initially, all materials are available.
    }

    /**
     * Checks if the material is currently available for loan. This method must be implemented
     * by subclasses as availability might depend on additional factors specific to the type of material.
     * @return true if the material is available for loan, false otherwise.
     */
    public abstract boolean isAvailable();


    public void setAvailable(boolean available) {
        this.available = available;
    }
    // Getters and setters for all fields
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getUniqueReference() {
        return uniqueReference;
    }

    public void setUniqueReference(String uniqueReference) {
        this.uniqueReference = uniqueReference;
    }

    public boolean isSuitableForChildren() {
        return suitableForChildren;
    }

    public void setSuitableForChildren(boolean suitableForChildren) {
        this.suitableForChildren = suitableForChildren;
    }

    public double getReplacementValue() {
        return replacementValue;
    }

    public void setReplacementValue(double replacementValue) {
        this.replacementValue = replacementValue;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    /**
     * Provides a string representation of the material's details.
     * @return A string detailing the material's attributes.
     */
    @Override
    public String toString() {
        return String.format("Title: %s, Reference: %s, Suitable for Children: %s, Replacement Value: %.2f, Location: %s",
                title, uniqueReference, suitableForChildren ? "Yes" : "No", replacementValue, location);
    }
}
