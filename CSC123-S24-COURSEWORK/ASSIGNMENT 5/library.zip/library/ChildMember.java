

import java.text.SimpleDateFormat;
import java.util.Date;

public class ChildMember extends Member {
    private AdultMember guardian; // The child's guardian, an adult member



    /**
     * Constructor to initialize a ChildMember object.
     * @param firstName The first name of the child member.
     * @param lastName The last name of the child member.
     * @param dateOfBirth The date of birth of the child member.
     * @param city The city where the child member resides.
     * @param zipCode The postal code of the child member's city.
     * @param membershipNumber The unique membership number assigned to the child member.
     * @param guardian The AdultMember who acts as the guardian to this child member.
     */
    public ChildMember(String firstName, String lastName, Date dateOfBirth, String city, String zipCode, String membershipNumber, AdultMember guardian) {
        super(firstName, lastName, dateOfBirth, city, zipCode, membershipNumber);
        this.guardian = guardian;
    }

    /**
     * Gets the guardian of the child member.
     * @return The AdultMember who is the guardian of the child member.
     */
    public AdultMember getGuardian() {
        return guardian;
    }

    /**
     * Sets the guardian for the child member.
     * @param guardian The AdultMember to be set as the guardian.
     */
    public void setGuardian(AdultMember guardian) {
        this.guardian = guardian;
    }

    /**
     * Returns a string representation of the child member's details including the guardian's information.
     * @return A string containing all relevant details of the child member and their guardian.
     */
    @Override
    public String toString() {
        SimpleDateFormat df = new SimpleDateFormat("MM/dd/yyyy");
        return "Child," + super.toString() + "," + guardian.getMembershipNumber();
    }


    /**
     * Overridden method to ensure it always returns true for instances of ChildMember.
     * @return true, indicating this member is a child.
     */
    @Override
    public boolean isChild() {
        return true;
    }
}
