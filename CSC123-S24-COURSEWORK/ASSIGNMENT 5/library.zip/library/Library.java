



import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import java.util.List;
import java.util.stream.Collectors;
import java.lang.reflect.Type;
import java.util.ArrayList;
public class Library {
    private List<Member> members; // Stores all members of the library
    private List<Material> catalogue; // Stores all materials available in the library
    private List<Loan> loans; // Tracks all current loans

    public Library() {
        this.members = new ArrayList<>();
        this.catalogue = new ArrayList<>();
        this.loans = new ArrayList<>();
    }

    public void saveLibraryState() throws IOException {
        saveMembers();
        saveMaterials();
        saveLoans();
    }

    private void saveMembers() throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter("members.txt"));
        for (Member member : members) {
            writer.write(member.toString());
            writer.newLine();
        }
        writer.close();
    }

    private void saveMaterials() throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter("materials.txt"));
        for (Material material : catalogue) {
            writer.write(material.toString());
            writer.newLine();
        }
        writer.close();
    }

    private void saveLoans() throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter("loans.txt"));
        for (Loan loan : loans) {
            writer.write(loan.toString());
            writer.newLine();
        }
        writer.close();
    }

    public void loadLibraryState() throws IOException {
        loadMembers();
        loadMaterials();
        loadLoans();
    }

    private void loadMembers() throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader("members.txt"));
        String line;
        while ((line = reader.readLine()) != null) {
            // Assuming a method parseMember that reconstructs a Member from a string
            Member member = parseMember(line);
            members.add(member);
        }
        reader.close();
    }
    private Member parseMember(String line) {
        String[] parts = line.split(",");
        if (parts.length < 6) {
            throw new RuntimeException("Invalid member data format");
        }
        String type = parts[0];
        String membershipNumber = parts[1];
        String fullName = parts[2];
        String[] names = fullName.split(" ");
        String firstName = names[0];
        String lastName = (names.length > 1) ? names[1] : ""; // Handling single names
        Date dob = parseDate(parts[3]);
        String city = parts[4];
        String zip = parts[5];

        if (type.equals("Adult")) {
            return new AdultMember(firstName, lastName, dob, city, zip, membershipNumber);
        } else if (type.equals("Child")) {
            if (parts.length < 7) {
                throw new RuntimeException("Missing guardian information for child member.");
            }
            String guardianMembershipNumber = parts[6];
            AdultMember guardian = (AdultMember) findMemberByMembershipNumber(guardianMembershipNumber);
            if (guardian == null) {
                throw new RuntimeException("Guardian with membership number " + guardianMembershipNumber + " not found.");
            }
            return new ChildMember(firstName, lastName, dob, city, zip, membershipNumber, guardian);
        } else {
            throw new RuntimeException("Unknown member type: " + type);
        }
    }



    private Material parseMaterial(String line) {
        String[] parts = line.split(",");
        String type = parts[0];
        if (parts.length < 8) throw new RuntimeException("Incorrect material data format");

        String title = parts[1];
        String uniqueReference = parts[2];
        boolean suitableForChildren = Boolean.parseBoolean(parts[3]);
        double replacementValue = Double.parseDouble(parts[4]);
        String location = parts[5];

        switch (type) {
            case "Book":
                if (parts.length < 9) throw new RuntimeException("Incorrect data for Book");
                String author = parts[6];
                String isbn = parts[7];
                int pages = Integer.parseInt(parts[8]);
                return new Book(title, uniqueReference, suitableForChildren, replacementValue, location, author, isbn, pages);
            case "Magazine":
                if (parts.length < 8) throw new RuntimeException("Incorrect data for Magazine");
                Date publicationDate = parseDate(parts[6]);
                int issueNumber = Integer.parseInt(parts[7]);
                return new Magazine(title, uniqueReference, suitableForChildren, replacementValue, location, publicationDate, issueNumber);
            case "DVD":
                if (parts.length < 8) throw new RuntimeException("Incorrect data for DVD");
                Date releaseDate = parseDate(parts[6]);
                int duration = Integer.parseInt(parts[7]);
                return new DVD(title, uniqueReference, suitableForChildren, replacementValue, location, releaseDate, duration);
            default:
                throw new IllegalArgumentException("Unknown material type: " + type);
        }
    }

    private Loan parseLoan(String line) {
        String[] parts = line.split(",");
        if (parts.length < 5) {
            throw new RuntimeException("Incorrect data format for loans");
        }

        String itemReference = parts[0];
        String title = parts[1];
        String membershipNumber = parts[2];
        String borrowerName = parts[3];
        Date dueDate = parseDate(parts[4]);

        return new Loan(itemReference, title, membershipNumber, borrowerName, dueDate);
    }

    private Date parseDate(String dateString) {
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
        try {
            return sdf.parse(dateString);
        } catch (ParseException e) {
            throw new RuntimeException("Date parsing error for input: " + dateString, e);
        }
    }

    private Member findMemberByMembershipNumber(String membershipNumber) {
        for (Member member : members) {
            if (member.getMembershipNumber().equals(membershipNumber)) {
                return member;
            }
        }
        return null; // Or handle this case appropriately
    }


    private void loadMaterials() throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader("materials.txt"));
        String line;
        while ((line = reader.readLine()) != null) {
            // Assuming a method parseMaterial that reconstructs a Material from a string
            Material material = parseMaterial(line);
            catalogue.add(material);
        }
        reader.close();
    }

    private void loadLoans() throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader("loans.txt"));
        String line;
        while ((line = reader.readLine()) != null) {
            // Assuming a method parseLoan that reconstructs a Loan from a string
            Loan loan = parseLoan(line);
            loans.add(loan);
        }
        reader.close();
    }

    /**
     * Adds a new member to the library.
     * @param member the member to add to the library
     */
    public void addMember(Member member) {
        members.add(member);
    }

    /**
     * Adds new material to the library's catalogue.
     * @param material the material to be added to the catalogue
     */
    public void addMaterial(Material material) {
        catalogue.add(material);
    }

    /**
     * Issues an item to a member if available.
     * @param membershipNumber the membership number of the member
     * @param itemReference the reference number of the item to issue
     */
    public void issueItem(String membershipNumber, String itemReference) throws Exception {
        Material material = catalogue.stream()
                .filter(m -> m.getUniqueReference().equals(itemReference))
                .findFirst()
                .orElse(null);

        if (material == null) {
            throw new IllegalArgumentException("Item does not exist");
        }

        if (!material.isAvailable()) {
            throw new IllegalArgumentException("Item on loan");
        }

        Member member = members.stream()
                .filter(m -> m.getMembershipNumber().equals(membershipNumber))
                .findFirst()
                .orElse(null);

        if (member == null) {
            throw new IllegalArgumentException("Member does not exist");
        }

        Date dueDate = calculateDueDate(material);
        Loan loan = new Loan(itemReference, material.getTitle(), membershipNumber, member.getFullName(), dueDate);
        loans.add(loan);
        material.setAvailable(false); // Update the material's availability status
    }


    /**
     * Returns an item and updates its status to available.
     * @param itemReference the reference number of the item to return
     */
    public void returnItem(String itemReference) {
        Loan loan = loans.stream()
                .filter(l -> l.getItemReference().equals(itemReference))
                .findFirst()
                .orElse(null);

        if (loan == null) {
            throw new IllegalArgumentException("Loan does not exist");
        }

        Material material = catalogue.stream()
                .filter(m -> m.getUniqueReference().equals(itemReference))
                .findFirst()
                .orElse(null);

        if (material != null) {
            material.setAvailable(true);
        }

        loans.remove(loan);
    }

    /**
     * Reports the inventory of the library.
     * @return a string detailing all materials and their availability
     */
    public String reportInventory() {
        StringBuilder report = new StringBuilder();
        String header = String.format("%-10s %-30s %-8s %-10s %-15s %-20s %-30s %-20s %-10s",
                "Type", "Title", "Ref", "Suitable", "Value ($)", "Location", "Specific Info", "ISBN/Date", "Pages/Duration");
        report.append(header);
        report.append("\n");

        catalogue.forEach(material -> {
            String[] parts = material.toString().split(",");
            String type = parts[0];
            String title = parts[1];
            String uniqueRef = parts[2];
            String suitableForChildren = parts[3].equals("true") ? "Yes" : "No";
            String replacementValue = parts[4];
            String location = parts[5];
            String specificInfo = "";
            String isbnOrDate = "";
            String pagesOrDuration = "";

            switch (type) {
                case "Book":
                    specificInfo = parts[6]; // Author
                    isbnOrDate = parts[7];   // ISBN
                    pagesOrDuration = parts[8]; // Pages
                    break;
                case "Magazine":
                    specificInfo = "Issue " + parts[7]; // Issue Number
                    isbnOrDate = parts[6];   // Publication Date
                    pagesOrDuration = "N/A";
                    break;
                case "DVD":
                    specificInfo = "Movie";
                    isbnOrDate = parts[6];   // Release Date
                    pagesOrDuration = parts[7] + " mins"; // Duration
                    break;
            }

            String line = String.format("%-10s %-30s %-8s %-10s %-15s %-20s %-30s %-20s %-10s",
                    type, title, uniqueRef, suitableForChildren, replacementValue, location, specificInfo, isbnOrDate, pagesOrDuration);
            report.append(line);
            report.append("\n");
        });

        return report.toString();
    }

    /**
     * Reports all current loans including member details and due dates.
     * @return a string listing all loans
     */
    public String reportLoans() {
        StringBuilder report = new StringBuilder();
        String header = String.format("%-10s %-30s %-15s %-20s %-15s",
                "Ref", "Title", "Member ID", "Borrower Name", "Due Date");
        report.append(header);
        report.append("\n");

        loans.forEach(loan -> {
            String itemReference = loan.getItemReference();
            String title = loan.getTitle();
            String membershipNumber = loan.getMembershipNumber();
            String borrowerName = loan.getBorrowerName();
            SimpleDateFormat df = new SimpleDateFormat("MM/dd/yyyy");
            String dueDate = df.format(loan.getDueDate());

            String line = String.format("%-10s %-30s %-15s %-20s %-15s",
                    itemReference, title, membershipNumber, borrowerName, dueDate);
            report.append(line);
            report.append("\n");
        });

        return report.toString();
    }


    /**
     * Looks up and displays details for a given membership number.
     * @param membershipId the membership number to lookup
     * @return details of the member associated with the membership number
     */
    public String lookupMembership(String membershipId) {
        Member member = members.stream()
                .filter(m -> m.getMembershipNumber().equals(membershipId))
                .findFirst()
                .orElse(null);

        if (member == null) {
            return "Member not found.";
        }

        StringBuilder details = new StringBuilder();
        SimpleDateFormat df = new SimpleDateFormat("MM/dd/yyyy");

        details.append("Member Details:\n");
        details.append(String.format("Type: %s\n", member instanceof AdultMember ? "Adult" : "Child"));
        details.append(String.format("Membership ID: %s\n", member.getMembershipNumber()));
        details.append(String.format("Name: %s %s\n", member.getFirstName(), member.getLastName()));
        details.append(String.format("Date of Birth: %s\n", df.format(member.getDateOfBirth())));
        details.append(String.format("City: %s\n", member.getCity()));
        details.append(String.format("Zip Code: %s\n", member.getZipCode()));

        if (member instanceof ChildMember) {
            AdultMember guardian = ((ChildMember) member).getGuardian();
            details.append("Guardian Details:\n");
            details.append(String.format("Guardian Name: %s %s\n", guardian.getFirstName(), guardian.getLastName()));
            details.append(String.format("Guardian Membership ID: %s\n", guardian.getMembershipNumber()));
        }

        return details.toString();
    }


    /**
     * Helper method to calculate the due date based on the type of material.
     * @param material the material being loaned out
     * @return the due back date as a Date object
     */
    private Date calculateDueDate(Material material) {
        Calendar calendar = Calendar.getInstance();
        if (material instanceof Book) {
            calendar.add(Calendar.DAY_OF_MONTH, 7); // Books are loaned for one week
        } else if (material instanceof Magazine) {
            calendar.add(Calendar.DAY_OF_MONTH, 3); // Magazines are loaned for 3 days
        } else if (material instanceof DVD) {
            calendar.add(Calendar.HOUR, 48); // DVDs are loaned for 48 hours
        }
        return calendar.getTime();
    }

}
