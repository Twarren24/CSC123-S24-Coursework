

import java.text.SimpleDateFormat;
import java.util.Date;

import java.util.Date;

public class Magazine extends Material {
    private Date publicationDate;  // The publication date of the magazine
    private int issueNumber;       // The issue number of the magazine

    /**
     * Constructor for initializing a Magazine object.
     * @param title The title of the magazine.
     * @param uniqueReference The unique reference identifier for the magazine.
     * @param suitableForChildren Indicates whether the magazine is suitable for children.
     * @param replacementValue The replacement cost of the magazine.
     * @param location The physical location of the magazine within the library.
     * @param publicationDate The publication date of the magazine.
     * @param issueNumber The issue number of this magazine.
     */
    public Magazine(String title, String uniqueReference, boolean suitableForChildren, double replacementValue, String location, Date publicationDate, int issueNumber) {
        super(title, uniqueReference, suitableForChildren, replacementValue, location);
        this.publicationDate = publicationDate;
        this.issueNumber = issueNumber;
    }

    // Getters and setters for magazine-specific fields
    public Date getPublicationDate() {
        return publicationDate;
    }

    public void setPublicationDate(Date publicationDate) {
        this.publicationDate = publicationDate;
    }

    public int getIssueNumber() {
        return issueNumber;
    }

    public void setIssueNumber(int issueNumber) {
        this.issueNumber = issueNumber;
    }

    /**
     * Checks if the magazine is currently available for loan.
     * @return true if the magazine is not currently loaned out, false otherwise.
     */
    @Override
    public boolean isAvailable() {
        return available;
    }

    /**
     * Provides a string representation of the magazine's details.
     * @return A string detailing the magazine's attributes including publication date and issue number.
     */
    @Override
    public String toString() {
        SimpleDateFormat df = new SimpleDateFormat("MM/dd/yyyy");
        return String.join(",",
                "Magazine",
                getTitle(),
                getUniqueReference(),
                String.valueOf(isSuitableForChildren()),
                String.format("%.2f", getReplacementValue()),
                getLocation(),
                df.format(getPublicationDate()),
                String.valueOf(getIssueNumber())
        );
    }
}

